# Object Detection Image Tagging: Fruits > 2022-08-02 1:07pm
https://universe.roboflow.com/object-detection/object-detection-image-tagging:-fruits

Provided by Roboflow
License: CC BY 4.0

Fruits Detection